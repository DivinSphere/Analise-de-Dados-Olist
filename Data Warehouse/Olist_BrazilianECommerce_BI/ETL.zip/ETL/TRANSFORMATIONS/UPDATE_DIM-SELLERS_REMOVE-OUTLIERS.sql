UPDATE [Brazilian_Ecommerce_DW].[dim].[DimSellers]
SET [seller_state] = 'RJ'
WHERE [seller_state] = ' rio de janeiro, brasil",RJ'
/*

(1 row affected)

Completion time: 2022-09-23T20:28:11.4143151-03:00
*/
UPDATE [Brazilian_Ecommerce_DW].[dim].[DimSellers]
SET [seller_state] = 'RS'
WHERE [seller_state] = ' rio grande do sul, brasil",RS'
/*

(1 row affected)

Completion time: 2022-09-23T22:29:23.4143151-03:00
*/