select * from sys.dm_db_index_physical_stats(DB_ID(),null,null,null,null)

select * from sys.indexes